// Copyright 2016 Google Inc. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import UIKit
import SwiftyJSON
import Foundation
import Alamofire

extension String {
    func indexDistance(of character: Character) -> Int {
        guard let index = index(of: character) else { return 0 }
        return distance(from: startIndex, to: index)
    }
}

// Grocery Dictionary
let grocery_dict: [String] = ["apple", "lemon", "sugar", "flour", "pancake", "grapes", "pumpkin", "syrup", "honeycomb", "honey", "banana", "tomatoe", "potatoe", "broccoli", "pea", "lettuce", "vodka sauce", "tea", "chicken", "kielbasa", "coke", "bean", "decceco", "rotini", "alfredo", "egg", "sausage", "oil", "oatmeal", "cheerios", "tuna", "bean", "chicken broth", "diet coke", "half and half", "water", "apple juice", "craneberry", "blueberry", "strawberry", "raseberry", "hummus", "ketchup", "mustard", "relish", "italian", "ranch", "coleslaw", "pickle", "dragon fruit", "clementine", "tortilla", "horseradish", "chocolate syrup", "soy sauce", "avocado", "corn", "lime", "butter", "apricot", "mozzarella", "cilantro", "parsley", "jerky", "turkey", "ham", "salami", "pepperoni", "wine", "rice", "milk", "pepper", "peanut", "cashew", "onion", "salt", "pam", "vinegar", "ice cream", "cream cheese", "corn starch", "carrot", "cheese", "shrimp", "beef", "fish", "quinoa", "peanut butter", "jelly", "sweet potatoe", "cumin", "spinach", "ritz", "wheat thins", "asparagus", "beet", "cabbage", "cauliflower", "celery", "cucumber", "kale", "squash", "chestnut", "zucchini", "almond", "blackberry", "cantaloupe", "date", "fig", "melon", "mango", "honeydew", "tangerine", "watermelon", "curry", "ginger", "pork", "lamb", "rabbit", "crab", "lobster", "oyster", "scallop", "goat cheese", "cow cheese", "sheep cheese", "plum", "peach", "whipping cream", "alcohol", "chocolate", "tahini", "chick pea", "kidney bean", "lima", "pinto", "soya", "mushroom", "mayonaise", "tabasco", "jalapeno", "salsa", "steak", "pizza crust", "pie crust", "green bean", "chili", "bread", "roll", "yogurt", "parmesan", "sour cream", "prune", "pure leaf tea", "barilla campanel", "mac and cheese", "cream cheese", "bagel", "cake mix"]


// Global Lists
var currentList: [String] = []
var groceryList: [String] = []


// UserDefaults
let userDefaults = UserDefaults.standard

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate  {
    let imagePicker = UIImagePickerController()
    let session = URLSession.shared
    var letters = CharacterSet.letters
    var digits = CharacterSet.decimalDigits
    
    // Google API information
    var googleAPIKey = "AIzaSyBYZBk58wFAI9cfsm9_sRevG23vEvTSVac"
    var googleURL: URL {
        return URL(string: "https://vision.googleapis.com/v1/images:annotate?key=\(googleAPIKey)")!
    }
    
    
    // Get User Input
    func getUserInput(_ userInput: UITextField) {
        var text: String = userInput.text!
        userDefaults.set(1, forKey: text)
        
        for (key, value) in userDefaults.dictionaryRepresentation() {
            let t = key as String
            text += t
        }
    }
    
    func textFieldShouldReturn(_ userInput: UITextField) -> Bool {
        userInput.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ userInput: UITextField) {
        getUserInput(userInput)
    }
    

    // Buttons
    // Camera Roll Button
    @IBAction func loadImageButtonTapped(_ sender: UIButton) {
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    
    // Take Photo Button
    @IBAction func takePhoto(_ sender: UIButton) {
        imagePicker.delegate = self
        imagePicker.sourceType = .camera
        present(imagePicker, animated: true, completion: nil)
        
    }
    
    // Add New Item Button
    @IBAction func addNewItem(_ sender: AnyObject) {
        performSegue(withIdentifier: "newItemsFromItem", sender: self)
    }
    
    // View Groceries Button
    @IBAction func viewGroceriesButton(_ sender: UIButton) {
        performSegue(withIdentifier: "viewGroceries1", sender: self)
        
    }
    
    
    // Built-in Required Functions
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        imagePicker.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}



//------------------------------------------------BEGINNING OF IMAGEPICKER API ----------------------------------------//
extension ViewController {
    
    func analyzeResults(_ dataToParse: Data) {
        
        // Update UI on the main thread
        DispatchQueue.main.async(execute: {
            
        // Use SwiftyJSON to parse results
        let json = JSON(data: dataToParse)
        let errorObj: JSON = json["error"]
        
            
            // Check for errors
        if (errorObj.dictionaryValue != [:]) {
                currentList.append("Error")
        } else  {
            // Parse the response
            let responses: JSON = json["responses"][0]
            
            // Get label annotations
            let labelAnnotations: JSON = responses["textAnnotations"]
            let numLabels: Int = labelAnnotations.count
            var labels: Array<String> = []
            var previousLabel = "none"
            var qty = "1"
            var pureLabels: [String] = []
            
            
            if numLabels > 0 {
                for index in 0..<numLabels {
                    let label = labelAnnotations[index]["description"].stringValue
                    labels.append(label)
                }
                for label in labels {
                    let label2 = label.lowercased()
                    print(label2)
                    var letterCount = 0
                    var digitCount = 0
                    
                    if label2 == "total" || label2 == "cash" {
                        continue
                    }
                    
                    // If quantity is given in receipt
                    if label2 == "qty" || label2 == "aty" {
                        qty = previousLabel
                        let labelTemp = pureLabels[pureLabels.count - 1]
                        currentList.removeLast()
                        currentList.append(labelTemp + " (" + qty + ")")
                        qty = "1"
                        continue
                    }
                    
                    if label2 == "lb" && !previousLabel.contains("/"){
                        qty = previousLabel
                        let labelTemp = pureLabels[pureLabels.count - 1]
                        currentList.removeLast()
                        currentList.append(labelTemp + " (" + qty + " lb)")
                        qty = "1"
                        continue
                    }
                    
                    for uni in label2.unicodeScalars {
                        if self.letters.contains(uni) {
                            letterCount += 1
                        } else if self.digits.contains(uni) {
                            digitCount += 1
                        }
                    }
                    
                    if digitCount == 0 && label2.count > 3 {        // If only letters
                        if grocery_dict.contains(label2) || grocery_dict.contains(label2 + "s") {
                            if !currentList.contains(label2) {
                                pureLabels.append(label2)
                                currentList.append(label2 + " (" + qty + ")")
                            }
                        } else {                // check if any item in grocery_dict match all letters in label
                            var tempList = grocery_dict
                            var indexPrevious = -1
                            let firstLetter = String(label2.first!)
                            tempList = tempList.filter { $0.hasPrefix(firstLetter) }
                            for letter in label2 {
//                                tempList = tempList.filter { $0.contains(letter) && $0.indexDistance(of: letter) > indexPrevious }
                                for item in tempList {
                                    if item.contains(letter)  && item.indexDistance(of: letter) > indexPrevious {
                                        indexPrevious = item.indexDistance(of: letter)
                                        continue
                                    }
                                    tempList.remove(at: tempList.index(of: item)!)
                                    indexPrevious = item.indexDistance(of: letter)
                                }
                            }
                            if tempList.count > 0 {
                                if !currentList.contains(tempList.first!)  && tempList.first!.count > 1 {
                                    pureLabels.append(tempList.first!)
                                    currentList.append(tempList.first! + " (" + qty + ")")
                                }
                            }
                        }
                    }
                    previousLabel = label2
                }
            } else {
                currentList.append("None")
            }
            }
        })
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            //imageView.contentMode = .scaleAspectFit
            //imageView.isHidden = true // You could optionally display the image here by setting imageView.image = pickedImage
            
            // Base64 encode the image and create the request
            let binaryImageData = base64EncodeImage(pickedImage)
            createRequest(with: binaryImageData)
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func resizeImage(_ imageSize: CGSize, image: UIImage) -> Data {
        UIGraphicsBeginImageContext(imageSize)
        image.draw(in: CGRect(x: 0, y: 0, width: imageSize.width, height: imageSize.height))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        let resizedImage = UIImagePNGRepresentation(newImage!)
        UIGraphicsEndImageContext()
        return resizedImage!
    }
}


/// Networking

extension ViewController {
    func base64EncodeImage(_ image: UIImage) -> String {
        var imagedata = UIImagePNGRepresentation(image)
        
        // Resize the image if it exceeds the 2MB API limit
        if (imagedata?.count > 2097152) {
            let oldSize: CGSize = image.size
            let newSize: CGSize = CGSize(width: 800, height: oldSize.height / oldSize.width * 800)
            imagedata = resizeImage(newSize, image: image)
        }
        
        return imagedata!.base64EncodedString(options: .endLineWithCarriageReturn)
    }
    
    func createRequest(with imageBase64: String) {
        // Create our request URL
        
        var request = URLRequest(url: googleURL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(Bundle.main.bundleIdentifier ?? "", forHTTPHeaderField: "X-Ios-Bundle-Identifier")
        
        // Build our API request
        let jsonRequest = [
            "requests": [
                "image": [
                    "content": imageBase64
                ],
                "features": [
                    [
                        "type": "TEXT_DETECTION",
                        "maxResults": 10
                    ]
                ]
            ]
        ]
        let jsonObject = JSON(jsonDictionary: jsonRequest)
        
        // Serialize the JSON
        guard let data = try? jsonObject.rawData() else {
            return
        }
        
        request.httpBody = data
        
        // Run the request on a background thread
        DispatchQueue.global().async { self.runRequestOnBackgroundThread(request) }
    }
    
    func runRequestOnBackgroundThread(_ request: URLRequest) {
        // run the request
        
        let task: URLSessionDataTask = session.dataTask(with: request) { (data, response, error) in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "")
                return
            }
            
            self.analyzeResults(data)
        }
        
        task.resume()
    }
}


// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l > r
    default:
        return rhs < lhs
    }
}
//------------------------------------------------END OF IMAGEPICKER API ----------------------------------------//



// ---------------------------------------------- New Classes/Views -----------------------------------------------//

// New items display
class DisplayViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource  {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return(currentList.count)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default , reuseIdentifier: "cell")
        cell.textLabel?.text = currentList[indexPath.row]
        
        return(cell)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("row: \(indexPath.row)")
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete
        {
            currentList.remove(at: indexPath.row)
            tableView.reloadData()
        }
    }
    
    // Table View New Items
    @IBOutlet weak var newItemsView: UITableView!
    
    @IBAction func confirmButton(_ sender: UIButton) {
        for item in currentList {
            groceryList.append(item)
        }
        
        // Permanently store data in userDefaults
        userDefaults.set(groceryList, forKey: "groceries")
        groceryList = userDefaults.stringArray(forKey: "groceries") ?? [String]()
        
        // Clearing current added items list
        currentList.removeAll()
        
        // FDA Database
//        let FDAurl = "https://api.nal.usda.gov/ndb/search/?format=json&ds=Standard%20Reference&q=butter&sort=r&max=1&offset=0&api_key=a1gxBh1kVI8hB554xEULhHZD9V2EW1UEcvqDjtPr"
//
//        Alamofire.request(FDAurl, method: .post, parameters: nil, encoding: JSONEncoding.default, headers: nil)
//            .responseJSON { response in
//                // print(response.result.value as Any) // URL response
//                // print(response.result as Any)
//                let result = response.result.value as! NSDictionary
//                let listResults = result["list"] as! NSDictionary
//                let itemResults = listResults["item"] as! NSArray
//                let itemString = itemResults[0] as! NSDictionary
//                //let itemArray = itemString.components(separatedBy: ";")
//                print(itemString["name"] as Any)
//        }

    }
    
    
    @IBAction func viewGroceriesButton(_ sender: AnyObject) {
        performSegue(withIdentifier: "viewGroceries", sender: self)
    }
    
}



    // Groceries View
class GroceryViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource  {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return(groceryList.count)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default , reuseIdentifier: "g_cell")
        cell.textLabel?.text = groceryList[indexPath.row]
        
        return(cell)
    }
    
    
    // Table View New Items
    @IBOutlet weak var groceriesView: UITableView!
    
    // Buttons
    // Return to Main Button
    @IBAction func returnToMain(_ sender: AnyObject) {
        performSegue(withIdentifier: "returnToMain", sender: self)
    }
    
    // Refresh Button
    @IBAction func refreshButton(_ sender: UIButton) {
        groceryList = userDefaults.stringArray(forKey: "groceries") ?? [String]()
        groceriesView.reloadData()
    }
    
    // Clear All Button
    @IBAction func clearAllButton(_ sender: UIButton) {
        let domain = Bundle.main.bundleIdentifier!
        userDefaults.removePersistentDomain(forName: domain)
        userDefaults.synchronize()
        print(Array(UserDefaults.standard.dictionaryRepresentation().keys).count)
    }
    
}

