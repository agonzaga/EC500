#import <Foundation/Foundation.h>
@interface PodsDummy_SwiftyJSON : NSObject
@end
@implementation PodsDummy_SwiftyJSON
@end
