#import <Foundation/Foundation.h>
@interface PodsDummy_Alamofire : NSObject
@end
@implementation PodsDummy_Alamofire
@end
